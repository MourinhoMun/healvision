export type { Case, SourceImage, GeneratedImage, Tag } from '@healvision/shared';

export interface DbRow {
  [key: string]: unknown;
}
